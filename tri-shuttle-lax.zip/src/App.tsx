import React, { useState, useEffect } from "react";
import CustomerView from "./components/CustomerView";
import AdminView from "./components/AdminView";
import DriverView from "./components/DriverView";
import { IBooking, IUser, RoleType } from "./types";
import { Users, Shield, Plane, RefreshCw, Layers, Sparkles, MapPin, CheckCircle } from "lucide-react";

export default function App() {
  const [currentRole, setCurrentRole] = useState<RoleType>("Customer");
  const [bookings, setBookings] = useState<IBooking[]>([]);
  const [users, setUsers] = useState<IUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load all bookings and users from server
  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);

      const [bookingsRes, usersRes] = await Promise.all([
        fetch("/api/bookings"),
        fetch("/api/users"),
      ]);

      if (!bookingsRes.ok || !usersRes.ok) {
        throw new Error("Lỗi khi tải dữ liệu từ máy chủ Tri Shuttle.");
      }

      const bookingsData = await bookingsRes.json();
      const usersData = await usersRes.json();

      setBookings(bookingsData);
      setUsers(usersData);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Không thể kết nối tới Backend.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    // Auto refresh every 15 seconds to simulate real-time operations
    const interval = setInterval(loadData, 15000);
    return () => clearInterval(interval);
  }, []);

  // Update a booking on backend and update locally
  const handleUpdateBooking = async (id: string, updates: Partial<IBooking>) => {
    try {
      const res = await fetch(`/api/bookings/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Lỗi cập nhật cuốc xe.");
      }

      const updatedBooking = await res.json();
      
      // Update local state immediately
      setBookings((prev) =>
        prev.map((b) => (b._id === id ? updatedBooking : b))
      );
    } catch (err: any) {
      console.error(err);
      alert("Lỗi thao tác máy chủ: " + err.message);
      throw err;
    }
  };

  // Delete booking on backend and update locally
  const handleDeleteBooking = async (id: string) => {
    try {
      const res = await fetch(`/api/bookings/${id}`, {
        method: "DELETE",
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || "Lỗi xóa cuốc xe.");
      }

      // Update local state immediately
      setBookings((prev) => prev.filter((b) => b._id !== id));
    } catch (err: any) {
      console.error(err);
      alert("Lỗi xóa cuốc xe: " + err.message);
      throw err;
    }
  };

  // Triggered when customer creates a booking
  const handleBookingCreated = (newBooking: IBooking) => {
    setBookings((prev) => [newBooking, ...prev]);
  };

  // Add new user (Driver or Admin)
  const handleCreateUser = async (user: Omit<IUser, "_id">) => {
    const res = await fetch("/api/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(user),
    });
    if (!res.ok) {
      const errorData = await res.json();
      throw new Error(errorData.error || "Lỗi khi thêm người dùng.");
    }
    const newUser = await res.json();
    setUsers((prev) => [...prev, newUser]);
  };

  return (
    <div className="min-h-screen bg-[#F5F5F0] text-[#2D2D2A] font-sans flex flex-col justify-between" id="app-wrapper">
      {/* Premium Header: Natural Tones */}
      <header className="bg-white border-b border-[#E6E6DF] shrink-0 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-[#5A5A40] rounded-full flex items-center justify-center shadow-inner">
              <span className="text-white font-serif italic text-xl">T</span>
            </div>
            <div>
              <h1 className="font-serif text-xl sm:text-2xl tracking-tight text-[#1A1A10] font-bold">
                Tri Shuttle Dispatch
              </h1>
              <p className="text-[9px] sm:text-[10px] uppercase tracking-widest text-[#8A8A7A] font-extrabold">
                LAX Private Luxury Transport • Operation Portal
              </p>
            </div>
          </div>

          {/* Quick Simulation Indicator */}
          <div className="hidden md:flex items-center gap-6">
            <div className="text-right">
              <p className="text-xs font-semibold text-[#1A1A10]">Console Điều Hành Sân Bay</p>
              <p className="text-[10px] text-[#5A5A40] font-medium">Bản cập nhật Nam California</p>
            </div>
            <div className="w-10 h-10 rounded-full border border-[#D4D4C8] p-0.5 bg-[#FAFBF7]">
              <div className="w-full h-full bg-[#E0E0D5] rounded-full flex items-center justify-center font-bold font-serif text-sm text-[#5A5A40]">
                LA
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Role Selector Header */}
      <div className="bg-[#E6E6DF] border-b border-[#D4D4C8] py-3.5 px-4 sticky top-20 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-3">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#5A5A40]" />
            <span className="text-xs font-bold text-[#5A5A40] uppercase tracking-wider">
              Môi trường Mô Phỏng (Role-based Simulator):
            </span>
          </div>

          {/* Role selection pills */}
          <div className="flex bg-white/70 p-1 rounded-full border border-[#D4D4C8] shadow-inner gap-1">
            <button
              onClick={() => setCurrentRole("Customer")}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 ${
                currentRole === "Customer"
                  ? "bg-[#5A5A40] text-white shadow-sm"
                  : "text-[#5A5A40] hover:bg-slate-100"
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              1. Khách Hàng đặt xe
            </button>
            <button
              onClick={() => setCurrentRole("Admin")}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 ${
                currentRole === "Admin"
                  ? "bg-[#5A5A40] text-white shadow-sm"
                  : "text-[#5A5A40] hover:bg-slate-100"
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              2. Quản Trị (Admin Panel)
              {bookings.filter((b) => b.status === "Pending").length > 0 && (
                <span className="bg-amber-500 text-slate-950 text-[10px] w-5 h-5 rounded-full flex items-center justify-center font-extrabold animate-pulse">
                  {bookings.filter((b) => b.status === "Pending").length}
                </span>
              )}
            </button>
            <button
              onClick={() => setCurrentRole("Driver")}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 ${
                currentRole === "Driver"
                  ? "bg-[#5A5A40] text-white shadow-sm"
                  : "text-[#5A5A40] hover:bg-slate-100"
              }`}
            >
              <Plane className="w-3.5 h-3.5" />
              3. Tài Xế (Driver App)
            </button>
          </div>
        </div>
      </div>

      {/* Main Operational Stage */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-8" id="main-content-area">
        {loading && bookings.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
            <RefreshCw className="w-8 h-8 text-[#5A5A40] animate-spin" />
            <p className="font-serif text-lg text-slate-600">Đang đồng bộ hóa dữ liệu Tri Shuttle LAX...</p>
          </div>
        ) : error ? (
          <div className="bg-rose-100 border border-rose-300 text-rose-800 rounded-2xl p-6 text-center max-w-lg mx-auto space-y-4">
            <h3 className="font-serif text-lg font-bold">Lỗi Kết Nối Máy Chủ</h3>
            <p className="text-sm">{error}</p>
            <button
              onClick={loadData}
              className="px-6 py-2.5 bg-[#5A5A40] text-white text-xs font-bold rounded-xl hover:bg-opacity-95"
            >
              Thử kết nối lại
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Quick overview widget at top of main */}
            {currentRole === "Customer" && (
              <div className="bg-[#FAFBF7] border border-[#E6E6DF] rounded-2xl p-4 flex flex-col sm:flex-row justify-between items-center gap-4 mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-2.5 h-2.5 bg-green-500 rounded-full animate-ping"></div>
                  <span className="text-xs font-semibold text-slate-600">
                    Sân bay LAX đang mở sảnh đón. Chuyến bay thẳng Vietnam Airlines VN521 và hàng trăm chuyến quốc tế khác đã sẵn sàng.
                  </span>
                </div>
                <button 
                  onClick={loadData}
                  className="text-xs font-bold text-[#5A5A40] hover:underline underline-offset-4 flex items-center gap-1 shrink-0"
                >
                  <RefreshCw className="w-3 h-3" /> Làm mới dữ liệu đặt chuyến
                </button>
              </div>
            )}

            {/* Render Views based on active Simulator Role */}
            {currentRole === "Customer" && (
              <CustomerView
                onBookingCreated={handleBookingCreated}
                recentBookings={bookings}
                onRefreshBookings={loadData}
              />
            )}

            {currentRole === "Admin" && (
              <AdminView
                bookings={bookings}
                users={users}
                onUpdateBooking={handleUpdateBooking}
                onDeleteBooking={handleDeleteBooking}
                onCreateUser={handleCreateUser}
                onRefresh={loadData}
              />
            )}

            {currentRole === "Driver" && (
              <DriverView
                bookings={bookings}
                users={users}
                onUpdateBooking={handleUpdateBooking}
                onRefresh={loadData}
              />
            )}
          </div>
        )}
      </main>

      {/* Footer Meta: Natural Tones */}
      <footer className="bg-white border-t border-[#E6E6DF] shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex flex-wrap gap-4 sm:gap-6 text-[9px] sm:text-[10px] uppercase tracking-widest text-[#8A8A7A] font-bold justify-center sm:justify-start">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              Real-time Sync: Active
            </span>
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              Fleet Health: Optimal
            </span>
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
              LAX Traffic: Moderate
            </span>
          </div>
          <span className="text-[10px] text-[#5A5A40] font-medium italic underline underline-offset-4 text-center">
            Trishuttle Official Management Console v2.1 • US West Region
          </span>
        </div>
      </footer>
    </div>
  );
}

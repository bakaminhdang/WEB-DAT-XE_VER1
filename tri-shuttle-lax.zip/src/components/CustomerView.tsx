import React, { useState } from "react";
import { IBooking } from "../types";
import { Plane, Phone, User, Briefcase, MapPin, CheckCircle, RefreshCw, AlertCircle, HelpCircle } from "lucide-react";

interface CustomerViewProps {
  onBookingCreated: (booking: IBooking) => void;
  recentBookings: IBooking[];
  onRefreshBookings: () => void;
}

export default function CustomerView({ onBookingCreated, recentBookings, onRefreshBookings }: CustomerViewProps) {
  const [serviceType, setServiceType] = useState<"pickup" | "dropoff">("pickup");
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [flightNumber, setFlightNumber] = useState("");
  const [terminal, setTerminal] = useState("Tom Bradley International Terminal");
  const [pickupPillar, setPickupPillar] = useState("");
  const [address, setAddress] = useState("");
  const [luggageCount, setLuggageCount] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [successBooking, setSuccessBooking] = useState<IBooking | null>(null);

  const terminals = [
    "Tom Bradley International Terminal (TBIT)",
    "Terminal 1",
    "Terminal 2",
    "Terminal 3",
    "Terminal 4",
    "Terminal 5",
    "Terminal 6",
    "Terminal 7",
    "Terminal 8"
  ];

  const popularAddresses = [
    "Westminster, California (Little Saigon)",
    "Garden Grove, California",
    "Irvine, California",
    "Anaheim (Disneyland Resort), CA",
    "Santa Ana, California",
    "Costa Maria, California"
  ];

  // Suggest vehicle based on luggage
  const getVehicleSuggestion = (count: number) => {
    if (count <= 2) {
      return {
        name: "Standard Luxury Sedan",
        models: "Lexus ES, Cadillac CT6, Mercedes-Benz E-Class",
        capacity: "Lên tới 3 khách, tối đa 2 vali lớn",
        badge: "Tiết kiệm & Sang trọng",
        color: "from-slate-700 to-slate-900",
      };
    } else if (count <= 4) {
      return {
        name: "Premium Luxury SUV",
        models: "Lincoln Navigator, Cadillac Escalade, GMC Yukon Denali",
        capacity: "Lên tới 6 khách, tối đa 5 vali lớn",
        badge: "Rộng rãi & Cao cấp",
        color: "from-amber-700 to-amber-900",
      };
    } else {
      return {
        name: "High-Capacity Passenger Van",
        models: "Ford Transit Premium, Mercedes-Benz Sprinter",
        capacity: "Lên tới 14 khách, tối đa 12 vali lớn",
        badge: "Đoàn lớn & Nhiều hành lý",
        color: "from-emerald-800 to-teal-900",
      };
    }
  };

  const vehicle = getVehicleSuggestion(luggageCount);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim() || !flightNumber.trim() || !address.trim()) {
      setErrorMsg("Vui lòng điền đầy đủ các thông tin bắt buộc (*).");
      return;
    }

    setSubmitting(true);
    setErrorMsg("");

    try {
      const response = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer_name: customerName,
          customer_phone: customerPhone,
          flight_number: flightNumber.toUpperCase(),
          airport_terminal: terminal,
          pickup_pillar: serviceType === "pickup" ? pickupPillar : "N/A (Dropoff)",
          dropoff_address: address,
          luggage_count: luggageCount,
        }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || "Không thể gửi đơn đặt xe");
      }

      const newBooking = await response.json();
      setSuccessBooking(newBooking);
      onBookingCreated(newBooking);

      // Reset form
      setCustomerName("");
      setCustomerPhone("");
      setFlightNumber("");
      setPickupPillar("");
      setAddress("");
      setLuggageCount(1);
    } catch (err: any) {
      setErrorMsg(err.message || "Đã xảy ra lỗi khi gửi yêu cầu.");
    } finally {
      setSubmitting(false);
    }
  };

  // Find passenger's recent active booking for tracker display
  const myTrackerBooking = successBooking
    ? recentBookings.find((b) => b._id === successBooking._id) || successBooking
    : null;

  return (
    <div className="max-w-4xl mx-auto py-4 px-2" id="customer-view-root">
      {/* Brand Header */}
      <div className="text-center mb-8">
        <span className="bg-amber-500/10 text-amber-500 text-xs font-bold tracking-widest uppercase px-3 py-1 rounded-full border border-amber-500/20">
          Tri Shuttle LAX Premium
        </span>
        <h1 className="text-3xl font-bold text-slate-100 tracking-tight mt-3">
          Đặt Xe Đưa Đón Sân Bay LAX Tư Nhân
        </h1>
        <p className="text-sm text-slate-400 mt-2 max-w-lg mx-auto">
          Dịch vụ trung chuyển cao cấp giữa Sân bay Los Angeles (LAX) và Little Saigon (Westminster, Garden Grove), Irvine và các khu lân cận.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        {/* Left Column: Form / Success Card */}
        <div className="md:col-span-7">
          {myTrackerBooking ? (
            <div className="bg-slate-800/90 border border-amber-500/30 rounded-2xl p-6 shadow-xl relative overflow-hidden" id="booking-success-card">
              <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full -mr-10 -mt-10 blur-xl"></div>
              
              <div className="flex items-center gap-3 text-amber-500 mb-4">
                <CheckCircle className="w-8 h-8" />
                <div>
                  <h3 className="font-bold text-lg text-slate-100">Đặt Xe Thành Công!</h3>
                  <p className="text-xs text-slate-400">Yêu cầu đã được lưu trên hệ thống</p>
                </div>
              </div>

              {/* Status Tracker */}
              <div className="bg-slate-900/80 rounded-xl p-4 border border-slate-700/60 mb-6">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Trạng thái cuốc xe:</span>
                  <span className={`text-xs font-bold px-2 py-1 rounded-md ${
                    myTrackerBooking.status === "Pending" ? "bg-amber-500/20 text-amber-400 animate-pulse" :
                    myTrackerBooking.status === "Active" ? "bg-blue-500/20 text-blue-400" :
                    myTrackerBooking.status === "Completed" ? "bg-emerald-500/20 text-emerald-400" :
                    "bg-rose-500/20 text-rose-400"
                  }`}>
                    {myTrackerBooking.status === "Pending" && "● Đang chờ Admin duyệt"}
                    {myTrackerBooking.status === "Active" && "● Đã duyệt & Có Tài xế"}
                    {myTrackerBooking.status === "Completed" && "✓ Đã hoàn thành"}
                    {myTrackerBooking.status === "Cancelled" && "✕ Đã hủy"}
                  </span>
                </div>

                <div className="space-y-3 pt-2 text-sm border-t border-slate-800">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Mã đơn đặt xe:</span>
                    <span className="font-mono text-slate-200">{myTrackerBooking._id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Khách hàng:</span>
                    <span className="font-semibold text-slate-200">{myTrackerBooking.customer_name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Mã chuyến bay:</span>
                    <span className="font-semibold text-amber-400">{myTrackerBooking.flight_number}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Terminal:</span>
                    <span className="text-slate-200">{myTrackerBooking.airport_terminal}</span>
                  </div>
                  {myTrackerBooking.pickup_pillar && myTrackerBooking.pickup_pillar !== "N/A (Dropoff)" && (
                    <div className="flex justify-between">
                      <span className="text-slate-400">Cột đón dự kiến:</span>
                      <span className="bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded text-xs font-semibold">{myTrackerBooking.pickup_pillar}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-slate-400">Địa chỉ tại US:</span>
                    <span className="text-slate-200 truncate max-w-[200px]">{myTrackerBooking.dropoff_address}</span>
                  </div>
                </div>

                {/* Driver Box (if active) */}
                {myTrackerBooking.status === "Active" && myTrackerBooking.driver_id && (
                  <div className="mt-4 p-3 bg-blue-950/40 border border-blue-500/30 rounded-lg">
                    <p className="text-xs font-semibold text-blue-400 uppercase tracking-wider mb-1">Tài xế được phân phối:</p>
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm font-bold text-slate-100">
                          {myTrackerBooking.driver_id === "driver_john_miller" ? "John Miller" : "Robert Chen"}
                        </p>
                        <p className="text-xs text-slate-300">
                          SĐT: {myTrackerBooking.driver_id === "driver_john_miller" ? "+1 714-555-0192" : "+1 949-555-0143"}
                        </p>
                      </div>
                      <a
                        href={`https://wa.me/${(myTrackerBooking.driver_id === "driver_john_miller" ? "17145550192" : "19495550143")}`}
                        target="_blank"
                        rel="noreferrer"
                        className="bg-emerald-600 hover:bg-emerald-500 text-slate-100 text-xs font-semibold px-2.5 py-1.5 rounded-md transition-colors flex items-center gap-1.5"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        Chat WhatsApp
                      </a>
                    </div>
                  </div>
                )}
              </div>

              {myTrackerBooking.status === "Pending" && (
                <div className="text-xs text-slate-400 flex items-start gap-1.5 bg-slate-900/50 p-3 rounded-lg border border-slate-800">
                  <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <span>
                    Hệ thống Tri Shuttle đang kiểm tra giờ đáp của bạn tại LAX. Admin sẽ sớm gán tài xế chuyên nghiệp đón bạn trực tiếp tại Terminal. Vui lòng giữ thiết bị có mạng để nhận tin nhắn qua WhatsApp/Zalo.
                  </span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => {
                    onRefreshBookings();
                  }}
                  className="flex-1 bg-slate-700 hover:bg-slate-600 text-slate-100 text-sm font-semibold py-2.5 rounded-xl transition-all flex items-center justify-center gap-2 border border-slate-600"
                >
                  <RefreshCw className="w-4 h-4" />
                  Cập nhật Trạng thái
                </button>
                <button
                  onClick={() => setSuccessBooking(null)}
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-slate-950 text-sm font-bold py-2.5 rounded-xl transition-all"
                >
                  Tạo Cuốc xe Mới
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="bg-slate-800/90 border border-slate-700 rounded-2xl p-6 shadow-xl" id="customer-booking-form">
              {/* Service Selection Toggle */}
              <div className="flex bg-slate-900 p-1 rounded-xl mb-6 border border-slate-700/60">
                <button
                  type="button"
                  onClick={() => {
                    setServiceType("pickup");
                    setPickupPillar("");
                  }}
                  className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                    serviceType === "pickup"
                      ? "bg-amber-500 text-slate-950 font-bold shadow"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  Airport Pickup (LAX → Về Nhà)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setServiceType("dropoff");
                    setPickupPillar("N/A (Dropoff)");
                  }}
                  className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                    serviceType === "dropoff"
                      ? "bg-amber-500 text-slate-950 font-bold shadow"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  Airport Dropoff (Nhà → LAX)
                </button>
              </div>

              {errorMsg && (
                <div className="bg-rose-500/15 border border-rose-500/30 text-rose-400 text-sm rounded-xl p-3 mb-4 flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <div className="space-y-4">
                {/* Full Name */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Họ & Tên Khách Hàng *
                  </label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Nguyễn Thu Anh"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl py-2.5 pl-10 pr-4 text-slate-200 text-sm focus:outline-none focus:border-amber-500 transition-colors"
                      required
                    />
                  </div>
                </div>

                {/* Phone Number (Supports Int'l formats like WhatsApp/Zalo) */}
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                      Số Điện Thoại (Quốc tế) *
                    </label>
                    <span className="text-[10px] text-amber-500">Hỗ trợ Zalo / WhatsApp</span>
                  </div>
                  <div className="relative">
                    <Phone className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                    <input
                      type="tel"
                      placeholder="Ví dụ: +84 901234567 hoặc +1 714-555-0192"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl py-2.5 pl-10 pr-4 text-slate-200 text-sm focus:outline-none focus:border-amber-500 transition-colors"
                      required
                    />
                  </div>
                </div>

                {/* Flight Number & Terminal */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                      Mã Chuyến Bay *
                    </label>
                    <div className="relative">
                      <Plane className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                      <input
                        type="text"
                        placeholder="Ví dụ: VN521, JL062, AA2412"
                        value={flightNumber}
                        onChange={(e) => setFlightNumber(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl py-2.5 pl-10 pr-4 text-slate-200 text-sm focus:outline-none focus:border-amber-500 transition-colors placeholder:text-slate-500"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                      LAX Terminal *
                    </label>
                    <select
                      value={terminal}
                      onChange={(e) => setTerminal(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl py-2.5 px-4 text-slate-200 text-sm focus:outline-none focus:border-amber-500 transition-colors"
                    >
                      {terminals.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Pickup Pillar (Only for Pickup) */}
                {serviceType === "pickup" && (
                  <div>
                    <div className="flex justify-between items-center mb-1.5">
                      <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                        Cột Đón Tại LAX (Pickup Pillar)
                      </label>
                      <span className="text-[10px] text-slate-400">Có thể điều chỉnh sau bởi điều phối viên</span>
                    </div>
                    <input
                      type="text"
                      placeholder="Ví dụ: Pillar 4B, Pillar 2A hoặc ghi 'Chưa rõ'"
                      value={pickupPillar}
                      onChange={(e) => setPickupPillar(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl py-2.5 px-4 text-slate-200 text-sm focus:outline-none focus:border-amber-500 transition-colors"
                    />
                  </div>
                )}

                {/* Dropoff Address (with fast list) */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    {serviceType === "pickup" ? "Địa Chỉ Trả Khách Tại US *" : "Địa Chỉ Đón Khách Đến Sân Bay *"}
                  </label>
                  <div className="relative mb-2">
                    <MapPin className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      placeholder={serviceType === "pickup" ? "Ví dụ: Garden Grove, Westminster, Irvine..." : "Nhập địa chỉ nhà của bạn tại Nam California"}
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl py-2.5 pl-10 pr-4 text-slate-200 text-sm focus:outline-none focus:border-amber-500 transition-colors"
                      required
                    />
                  </div>
                  {/* Quick selections */}
                  <div className="flex flex-wrap gap-1.5">
                    {popularAddresses.map((addr) => (
                      <button
                        key={addr}
                        type="button"
                        onClick={() => setAddress(addr)}
                        className="text-[10px] bg-slate-900/60 text-slate-300 hover:text-amber-400 border border-slate-700/60 rounded-full px-2.5 py-1 transition-colors"
                      >
                        {addr.split(",")[0]}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Luggage count */}
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                      Số Lượng Hành Lý (Luggage Count) *
                    </label>
                    <span className="text-xs text-slate-400 font-bold">{luggageCount} Vali</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={luggageCount}
                    onChange={(e) => setLuggageCount(Number(e.target.value))}
                    className="w-full accent-amber-500 bg-slate-900 h-2 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 px-1 mt-1 font-mono">
                    <span>1 Vali</span>
                    <span>3 Vali</span>
                    <span>5 Vali</span>
                    <span>7 Vali</span>
                    <span>10+ Vali</span>
                  </div>
                </div>
              </div>

              {/* Submit button */}
              <button
                type="submit"
                disabled={submitting}
                className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold py-3 px-4 rounded-xl shadow-lg shadow-amber-500/10 mt-6 transition-all hover:scale-[1.01] flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {submitting ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    Đang gửi yêu cầu đặt xe...
                  </>
                ) : (
                  "Gửi Đơn Đặt Xe Đưa Đón"
                )}
              </button>
            </form>
          )}
        </div>

        {/* Right Column: Fleet Guidance Info */}
        <div className="md:col-span-5 flex flex-col justify-between">
          <div className="bg-slate-800/60 border border-slate-700/80 rounded-2xl p-5 shadow-lg space-y-5">
            <h3 className="font-bold text-slate-200 text-sm border-b border-slate-700/80 pb-3 flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-amber-500" />
              Gợi Ý Dòng Xe Tri Shuttle Phù Hợp
            </h3>

            {/* Recommended Car Card */}
            <div className={`p-4 rounded-xl bg-gradient-to-br ${vehicle.color} text-slate-100 border border-white/5 shadow-inner`}>
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-bold bg-white/15 px-2 py-0.5 rounded-full border border-white/10 uppercase tracking-widest text-slate-200">
                  {vehicle.badge}
                </span>
                <span className="text-xs font-mono text-amber-400 font-bold">RECOMENDED</span>
              </div>
              <h4 className="text-lg font-extrabold tracking-tight mt-2">{vehicle.name}</h4>
              <p className="text-xs text-slate-300 mt-1 italic">{vehicle.models}</p>
              
              <div className="mt-4 pt-3 border-t border-white/10 flex items-center gap-2 text-xs text-slate-200 font-medium">
                <div className="w-1.5 h-1.5 bg-amber-400 rounded-full"></div>
                <span>Sức chứa hành lý: {vehicle.capacity}</span>
              </div>
            </div>

            {/* Standard Instructions */}
            <div className="text-xs text-slate-400 space-y-3">
              <h4 className="font-semibold text-slate-300">Hướng dẫn tại Sân bay LAX:</h4>
              <ul className="list-disc pl-4 space-y-1.5 leading-relaxed">
                <li>Khi chuyến bay hạ cánh và hoàn tất thủ tục hải quan/nhận hành lý, quý khách vui lòng di chuyển ra ngoài rìa sảnh đón (Arrivals level outer curb).</li>
                <li>Xác định đúng số cột (<span className="text-amber-400">Pillar</span>) và thông báo cho tài xế Tri Shuttle.</li>
                <li>Tài xế sẽ điều xe từ bãi đỗ vào đón quý khách trong vòng 3-5 phút để tránh bị phạt phạt đỗ xe quá giờ của ban quản lý sân bay LAX.</li>
              </ul>
            </div>
          </div>

          {/* Test Simulation Controls Notice */}
          <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-800 mt-4">
            <p className="text-[11px] text-slate-500 leading-relaxed">
              💡 <span className="font-bold text-slate-400">Cách hoạt động Mock Demo:</span> Sau khi gửi đơn đặt xe, trạng thái sẽ là <span className="text-amber-500 font-bold">Pending (Chờ duyệt)</span>. Bạn hãy click vào vai trò <span className="text-amber-500 font-bold">"Quản trị (Admin)"</span> trên thanh điều hướng phía trên để phê duyệt, kiểm tra thông tin bay qua Gemini AI và phân bổ tài xế!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

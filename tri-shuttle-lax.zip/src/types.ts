export interface IUser {
  _id: string;
  name: string;
  email: string;
  phone: string;
  role: "Admin" | "Driver";
}

export interface IBooking {
  _id: string;
  customer_name: string;
  customer_phone: string;
  flight_number: string;
  airport_terminal: string;
  pickup_pillar?: string;
  dropoff_address: string;
  luggage_count: number;
  status: "Pending" | "Active" | "Completed" | "Cancelled";
  driver_id: string | null;
  createdAt: string;
  updatedAt: string;
}

export type RoleType = "Customer" | "Admin" | "Driver";

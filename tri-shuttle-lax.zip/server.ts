import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { User, Booking } from "./src/backend/db.js";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON and URL-encoded body parsers
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Initialize Gemini Client server-side
  const ai = process.env.GEMINI_API_KEY
    ? new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      })
    : null;

  /**
   * API ROUTES
   */

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: new Date().toISOString() });
  });

  // Get all users (Admin & Drivers)
  app.get("/api/users", async (req, res) => {
    try {
      const users = await User.find();
      res.json(users);
    } catch (error: any) {
      res.status(500).json({ error: "Failed to fetch users: " + error.message });
    }
  });

  // Create a new user (Admin or Driver)
  app.post("/api/users", async (req, res) => {
    try {
      const { name, email, phone, role } = req.body;

      if (!name || !email || !phone || !role) {
        return res.status(400).json({ error: "Vui lòng điền đầy đủ Họ tên, Email, Số điện thoại và Vai trò." });
      }

      if (role !== "Admin" && role !== "Driver") {
        return res.status(400).json({ error: "Vai trò không hợp lệ. Phải là 'Admin' hoặc 'Driver'." });
      }

      // Check if email already exists
      const existing = await User.findOne({ email });
      if (existing) {
        return res.status(400).json({ error: "Email này đã được đăng ký trên hệ thống." });
      }

      const newUser = await User.create({
        name,
        email,
        phone,
        role,
      });

      res.status(201).json(newUser);
    } catch (error: any) {
      res.status(500).json({ error: "Không thể thêm tài khoản: " + error.message });
    }
  });

  // Get all bookings (with optional filter)
  app.get("/api/bookings", async (req, res) => {
    try {
      const { status, driver_id } = req.query;
      const filter: any = {};
      if (status) filter.status = status;
      if (driver_id) filter.driver_id = driver_id;

      const bookings = await Booking.find(filter);
      res.json(bookings);
    } catch (error: any) {
      res.status(500).json({ error: "Failed to fetch bookings: " + error.message });
    }
  });

  // Get a single booking
  app.get("/api/bookings/:id", async (req, res) => {
    try {
      const booking = await Booking.findById(req.params.id);
      if (!booking) {
        return res.status(404).json({ error: "Booking not found" });
      }
      res.json(booking);
    } catch (error: any) {
      res.status(500).json({ error: "Failed to fetch booking: " + error.message });
    }
  });

  // Create a new booking
  app.post("/api/bookings", async (req, res) => {
    try {
      const {
        customer_name,
        customer_phone,
        flight_number,
        airport_terminal,
        pickup_pillar,
        dropoff_address,
        luggage_count,
      } = req.body;

      if (!customer_name || !customer_phone || !flight_number || !airport_terminal || !dropoff_address) {
        return res.status(400).json({ error: "Missing required fields for booking." });
      }

      const newBooking = await Booking.create({
        customer_name,
        customer_phone,
        flight_number,
        airport_terminal,
        pickup_pillar: pickup_pillar || "",
        dropoff_address,
        luggage_count: Number(luggage_count) || 0,
        status: "Pending",
        driver_id: null,
      });

      res.status(201).json(newBooking);
    } catch (error: any) {
      res.status(500).json({ error: "Failed to create booking: " + error.message });
    }
  });

  // Update a booking (e.g. status dispatch, assign driver, change pillar)
  app.patch("/api/bookings/:id", async (req, res) => {
    try {
      const { status, driver_id, pickup_pillar, dropoff_address, luggage_count } = req.body;
      const bookingId = req.params.id;

      const existing = await Booking.findById(bookingId);
      if (!existing) {
        return res.status(404).json({ error: "Booking not found" });
      }

      const updates: any = {};
      if (status !== undefined) updates.status = status;
      if (driver_id !== undefined) updates.driver_id = driver_id === "" ? null : driver_id;
      if (pickup_pillar !== undefined) updates.pickup_pillar = pickup_pillar;
      if (dropoff_address !== undefined) updates.dropoff_address = dropoff_address;
      if (luggage_count !== undefined) updates.luggage_count = Number(luggage_count);

      const updated = await Booking.findByIdAndUpdate(bookingId, updates);
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ error: "Failed to update booking: " + error.message });
    }
  });

  // Delete a booking
  app.delete("/api/bookings/:id", async (req, res) => {
    try {
      const deleted = await Booking.deleteOne(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Booking not found" });
      }
      res.json({ success: true, message: "Booking deleted successfully." });
    } catch (error: any) {
      res.status(500).json({ error: "Failed to delete booking: " + error.message });
    }
  });

  // AI-powered flight check & validation endpoint (using Gemini 3.5 Flash)
  app.post("/api/validate-flight", async (req, res) => {
    try {
      const { flightNumber } = req.body;
      if (!flightNumber) {
        return res.status(400).json({ error: "Mã chuyến bay không được để trống." });
      }

      if (!ai) {
        // High-quality fallback if GEMINI_API_KEY is not defined yet
        return res.json({
          valid: true,
          airline: "Hãng hàng không (Giả lập)",
          terminal: "Terminal Quốc tế Tom Bradley (TBIT)",
          notes: "Lưu ý: Để kích hoạt kiểm tra mã bay tự động qua AI thời gian thực, vui lòng cấu hình `GEMINI_API_KEY` trong mục Secrets. Hệ thống đang tự động ước tính chuyến bay này hợp lệ cho Sân bay LAX.",
        });
      }

      const prompt = `Bạn là một AI phân tích thông tin hàng không chuyên nghiệp cho dịch vụ đón tiễn sân bay tại LAX (Los Angeles International Airport). 
Hãy kiểm tra mã chuyến bay này: "${flightNumber}". 
Yêu cầu:
1. Xác định định dạng mã bay có hợp lệ không.
2. Tìm tên Hãng hàng không (airline) hoạt động chuyến bay này.
3. Xác định Nhà ga (Terminal) điển hình đón trả khách của hãng bay này tại sân bay LAX (ví dụ: Tom Bradley International Terminal, Terminal 4, Terminal 7...).
4. Viết một đoạn tóm tắt chi tiết và trực quan bằng tiếng Việt (notes) phân tích nguồn gốc xuất phát phổ biến (ví dụ VN521 từ Sài Gòn, JL062 từ Tokyo), hướng dẫn vị trí đón tối ưu cho tài xế, và lưu ý về thời gian di chuyển.
Đầu ra phải tuân thủ đúng cấu trúc JSON đã được định nghĩa.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              valid: {
                type: Type.BOOLEAN,
                description: "True nếu mã bay đúng định dạng hàng không, False nếu là ký tự rác.",
              },
              airline: {
                type: Type.STRING,
                description: "Tên hãng hàng không đầy đủ (ví dụ: Vietnam Airlines, Japan Airlines, American Airlines).",
              },
              terminal: {
                type: Type.STRING,
                description: "Nhà ga đón khách tại LAX (ví dụ: Tom Bradley International Terminal (TBIT), Terminal 4, Terminal 6, etc.).",
              },
              notes: {
                type: Type.STRING,
                description: "Tóm tắt chi tiết, lời khuyên và hướng dẫn bằng tiếng Việt cho tài xế và điều phối viên về chuyến bay này.",
              },
            },
            required: ["valid", "airline", "terminal", "notes"],
          },
        },
      });

      const parsedResult = JSON.parse(response.text || "{}");
      res.json(parsedResult);
    } catch (error: any) {
      console.error("Gemini flight validation error:", error);
      res.status(500).json({ error: "Lỗi phân tích mã chuyến bay qua AI: " + error.message });
    }
  });

  /**
   * VITE OR STATIC SERVING MIDDLEWARE
   */
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Tri Shuttle Backend] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
